package main;

import model.Estudante;
import model.EstudanteBD;

public class TesteBD {

    static void tentar(EstudanteBD bd, String nome, String mat, String tel) {
        Estudante e = new Estudante();
        e.setNome(nome);
        e.setMatricula(mat);
        e.setTelefone(tel);
        try {
            bd.salvar(e);
            System.out.println("Gravado : " + nome + " / " + mat + " (total: " + bd.contar() + ")");
        } catch (IllegalArgumentException erro) {
            System.out.println("Recusado: " + nome + " / " + mat + " -> " + erro.getMessage());
        }
    }

    public static void main(String[] args) {
        EstudanteBD bd = new EstudanteBD();

        tentar(bd, "Ana Souza", "2026001", "47999990000");
        tentar(bd, "Bruno Lima", "2026002", "");
        tentar(bd, "", "2026003", "");
        tentar(bd, "Carla Nunes", "", "");
        tentar(bd, "Diego Alves", "2026001", "");
        tentar(bd, "Maria O'Brien", "2026004", "4733220000");

        // DESAFIO 1: telefone curto demais deve ser recusado; telefone
        // vazio continua sendo aceito (o campo e opcional).
        tentar(bd, "Elisa Prado", "2026005", "4799"); // menos de 8 -> recusado
        tentar(bd, "Fabio Rocha", "2026006", "");      // vazio -> aceito

        System.out.println("--- no banco agora ---");
        for (Estudante e : bd.listarTodos()) {
            System.out.println(" " + e.getNome() + " | " + e.getMatricula() + " | " + e.getTelefone());
        }

        // DESAFIO 4: buscarPorMatricula devolve o Estudante quando existe,
        // e null quando nao existe.
        System.out.println("--- testando buscarPorMatricula ---");
        Estudante achado = bd.buscarPorMatricula("2026001");
        System.out.println(achado != null
                ? "Achou: " + achado.getNome() + " | " + achado.getTelefone()
                : "Nao achou 2026001");

        Estudante naoAchado = bd.buscarPorMatricula("0000000");
        System.out.println(naoAchado == null ? "Nao achou 0000000 (esperado)" : "ERRO: achou algo indevido");
    }
}
