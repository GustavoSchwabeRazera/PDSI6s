package view;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

/**
 * VIEW - a mesma janela do roteiro, com os botoes dos desafios acrescentados.
 *
 * Confira com Ctrl+F: nao ha "addActionListener" e nao ha "if" de regra
 * nesta classe. O confirmarSaida() usa "if" so para devolver o boolean do
 * showConfirmDialog - continua sem nenhuma regra de negocio aqui.
 */
public class JanelaCadastro extends JFrame {

    private static final long serialVersionUID = 1L;

    private JPanel contentPane;

    private JTextField txtNome;
    private JTextField txtMatricula;
    private JTextField txtTelefone;

    // Botoes viram atributos porque quem pendura o ouvinte e o Controller,
    // e para isso ele precisa alcanca-los pelos getters.
    private JButton btnCadastrar;
    private JButton btnLimpar;
    private JButton btnFechar;

    // DESAFIO 2 e 4: mais dois botoes, mesma logica dos tres originais.
    private JButton btnListar;
    private JButton btnBuscar;

    public JanelaCadastro() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 340);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNome = new JLabel("Nome");
        lblNome.setBounds(10, 21, 77, 14);
        contentPane.add(lblNome);

        txtNome = new JTextField();
        txtNome.setBounds(110, 18, 96, 20);
        contentPane.add(txtNome);
        txtNome.setColumns(10);

        // 105 e nao 88: com 88 o texto aparece cortado como "Cada...".
        btnCadastrar = new JButton("Cadastrar");
        btnCadastrar.setBounds(238, 17, 105, 22);
        contentPane.add(btnCadastrar);

        JLabel lblMatricula = new JLabel("Matricula");
        lblMatricula.setBounds(10, 60, 76, 14);
        contentPane.add(lblMatricula);

        txtMatricula = new JTextField();
        txtMatricula.setBounds(110, 57, 96, 20);
        contentPane.add(txtMatricula);
        txtMatricula.setColumns(10);

        btnLimpar = new JButton("Limpar");
        btnLimpar.setBounds(238, 56, 105, 22);
        contentPane.add(btnLimpar);

        JLabel lblTelefone = new JLabel("Telefone");
        lblTelefone.setBounds(10, 100, 77, 14);
        contentPane.add(lblTelefone);

        txtTelefone = new JTextField();
        txtTelefone.setBounds(110, 97, 96, 20);
        contentPane.add(txtTelefone);
        txtTelefone.setColumns(10);

        btnFechar = new JButton("Fechar");
        btnFechar.setBounds(238, 96, 105, 22);
        contentPane.add(btnFechar);

        // DESAFIO 4: Buscar preenche os campos com o que a matricula digitada encontrar.
        btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(110, 135, 96, 22);
        contentPane.add(btnBuscar);

        // DESAFIO 2: Listar mostra todos os cadastros num JOptionPane.
        btnListar = new JButton("Listar");
        btnListar.setBounds(238, 135, 105, 22);
        contentPane.add(btnListar);
    }

    // ---- Grupo 1: entregar componentes ao Controller ------------------

    public JTextField getTxtNome() {
        return txtNome;
    }

    public JTextField getTxtMatricula() {
        return txtMatricula;
    }

    public JTextField getTxtTelefone() {
        return txtTelefone;
    }

    public JButton getBtnCadastrar() {
        return btnCadastrar;
    }

    public JButton getBtnLimpar() {
        return btnLimpar;
    }

    public JButton getBtnFechar() {
        return btnFechar;
    }

    public JButton getBtnListar() {
        return btnListar;
    }

    public JButton getBtnBuscar() {
        return btnBuscar;
    }

    // ---- Grupo 2: capacidades da propria tela -------------------------
    // Recebem o texto PRONTO (ou devolvem uma resposta simples). A View
    // exibe ou pergunta; nao decide o que fazer com o resultado.

    public void mostrarMensagem(String texto) {
        JOptionPane.showMessageDialog(this, texto);
    }

    public void mostrarErro(String texto) {
        JOptionPane.showMessageDialog(this, texto, "Atencao",
                JOptionPane.WARNING_MESSAGE);
    }

    public void limparCampos() {
        txtNome.setText("");
        txtMatricula.setText("");
        txtTelefone.setText("");
        txtNome.requestFocus();
    }

    public void fechar() {
        dispose();
    }

    /**
     * DESAFIO 3: quem exibe a caixa de confirmacao e a View - ela so
     * devolve a resposta (sim/nao) como boolean. O Controller decide o
     * que fazer com essa resposta (fechar ou nao); a View nao sabe disso.
     */
    public boolean confirmarSaida() {
        int resposta = JOptionPane.showConfirmDialog(this,
                "Deseja realmente sair?", "Confirmar saida",
                JOptionPane.YES_NO_OPTION);
        return resposta == JOptionPane.YES_OPTION;
    }
}
