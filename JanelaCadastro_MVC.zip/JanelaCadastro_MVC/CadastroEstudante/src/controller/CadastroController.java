package controller;

import model.Estudante;
import model.EstudanteBD;
import view.JanelaCadastro;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * CONTROLLER - e aqui que mora o codigo dos botoes, dos cinco agora.
 *
 * Um unico actionPerformed descobre qual botao foi clicado comparando
 * com e.getSource() (== e nao equals: a pergunta e "e exatamente aquele
 * objeto?").
 */
public class CadastroController implements ActionListener {

    private EstudanteBD bd;
    private JanelaCadastro view;

    public CadastroController(EstudanteBD bd, JanelaCadastro view) {
        this.bd = bd;
        this.view = view;

        // O "this" e o proprio Controller se registrando como ouvinte.
        this.view.getBtnCadastrar().addActionListener(this);
        this.view.getBtnLimpar().addActionListener(this);
        this.view.getBtnFechar().addActionListener(this);
        // DESAFIO 2 e 4: os dois botoes novos entram na mesma lista de ouvintes.
        this.view.getBtnListar().addActionListener(this);
        this.view.getBtnBuscar().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == this.view.getBtnCadastrar()) {
            cadastrar();
        } else if (e.getSource() == this.view.getBtnLimpar()) {
            this.view.limparCampos();
        } else if (e.getSource() == this.view.getBtnFechar()) {
            fechar();
        } else if (e.getSource() == this.view.getBtnListar()) {
            listar();
        } else if (e.getSource() == this.view.getBtnBuscar()) {
            buscar();
        }
    }

    private void cadastrar() {
        // 1. pede os dados a View
        Estudante estudante = new Estudante();
        estudante.setNome(this.view.getTxtNome().getText());
        estudante.setMatricula(this.view.getTxtMatricula().getText());
        estudante.setTelefone(this.view.getTxtTelefone().getText());

        // 2. entrega ao Model, que aplica as regras e grava
        try {
            this.bd.salvar(estudante);
        } catch (IllegalArgumentException erro) {
            // Repassa a mensagem sem saber qual regra falhou.
            this.view.mostrarErro(erro.getMessage());
            return; // sem o return, a mensagem de sucesso viria em seguida
        }

        // 3. deu certo
        this.view.mostrarMensagem("Cadastrado. Total no banco: " + this.bd.contar());
        this.view.limparCampos();
    }

    /**
     * DESAFIO 3: quem pergunta e a View (confirmarSaida); o Controller so
     * decide, com base na resposta, se chama view.fechar() ou nao.
     */
    private void fechar() {
        if (this.view.confirmarSaida()) {
            this.view.fechar();
        }
    }

    /**
     * DESAFIO 2: percorre bd.listarTodos() montando o texto com
     * StringBuilder e entrega pronto para a View exibir.
     */
    private void listar() {
        StringBuilder texto = new StringBuilder();
        for (Estudante e : this.bd.listarTodos()) {
            texto.append(e.getNome())
                 .append(" | ")
                 .append(e.getMatricula())
                 .append(" | ")
                 .append(e.getTelefone())
                 .append("\n");
        }
        if (texto.length() == 0) {
            this.view.mostrarMensagem("Nenhum cadastro no banco.");
        } else {
            this.view.mostrarMensagem(texto.toString());
        }
    }

    /**
     * DESAFIO 4: busca pela matricula digitada e preenche os campos com o
     * que encontrar. Se nao achar, avisa e limpa os campos.
     */
    private void buscar() {
        String matricula = this.view.getTxtMatricula().getText();
        Estudante encontrado = this.bd.buscarPorMatricula(matricula);

        if (encontrado == null) {
            this.view.mostrarErro("Nenhum cadastro encontrado para essa matricula.");
            return;
        }

        this.view.getTxtNome().setText(encontrado.getNome());
        this.view.getTxtMatricula().setText(encontrado.getMatricula());
        this.view.getTxtTelefone().setText(encontrado.getTelefone());
    }

    public void iniciarTela() {
        this.view.setVisible(true);
    }
}
